﻿using System;
using UnityEngine;

[RequireComponent(typeof(Light))]
public class Alarm : MonoBehaviour {
  public GameObject ball;
    public AudioSource alarmSound;
    // Use this for initialization
    void Start() {

  }

    void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject == ball)
        {
            alarmSound.Play();
        }
    }

    void OnTriggerExit(Collider collider)
    {
        if (collider.gameObject == ball)
        {
            alarmSound.Stop();
        }
        
    }
    

}
