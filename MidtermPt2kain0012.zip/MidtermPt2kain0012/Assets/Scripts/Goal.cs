﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class Goal : MonoBehaviour {
  public GameObject ball;
    public AudioSource goalSound;

    public void OnCollisionEnter(Collision collision)
    {
        // If the ball has touched the goal, then we want to play a sound.
        if (collision.collider.gameObject == ball)
        {
            goalSound.Play();
        }
        SceneManager.LoadScene("MainMenuScene");

    }
}
